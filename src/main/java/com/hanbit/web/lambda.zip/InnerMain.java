package com.hanbit.web.lambda;

public class InnerMain {
	public static void main(String[] args) {
		Greeting g = new Greeting();
		g.sayHello();
	}
}
